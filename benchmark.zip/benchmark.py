"""Performance comparison script for numpy vs jax backends."""
import pandas as pd
from gettsim import InputData, MainTarget, TTTargets, main
import time
import hashlib
import json
import os
from datetime import datetime
from make_data import make_data

# Use the same mapper as in the main script
MAPPER = {
    "alter": "age",
    "arbeitsstunden_w": "working_hours", 
    "behinderungsgrad": "disability_grade",
    "geburtsjahr": "birth_year",
    "hh_id": "hh_id",
    "p_id": "p_id",
    "wohnort_ost": "east_germany",
    "familie": {
        "alleinerziehend": "single_parent",
        "kind": "is_child",
        "p_id_ehepartner": "spouse_id",
        "p_id_elternteil_1": "parent_id_1",
        "p_id_elternteil_2": "parent_id_2",
    },
    "kindergeld": {
        "in_ausbildung": "in_training",
        "p_id_empfänger": "id_recipient_child_allowance",
    },
}

TT_TARGETS = {
    "einkommensteuer": {"betrag_m_sn": "income_tax_m"},
}

def run_benchmark(N_households, backend):
    print(f"Generating dataset with {N_households:,} households...")
    # Create dataset but don't include this time in benchmark
    data = make_data(N_households)
    print(f"Dataset shape: {data.shape}")
    
    print(f"Running with {backend} backend...")
    start_time = time.time()
    
    try:
        result = main(
            policy_date_str=None,
            input_data=InputData.df_and_mapper(
                df=data,
                mapper=MAPPER,
            ),
            main_targets=[MainTarget.processed_data],
            tt_targets=TTTargets(tree=TT_TARGETS),
            backend=backend,
        )
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # Calculate hash to verify result correctness
        result_hash = hashlib.md5(str(result).encode()).hexdigest()[:8]
        
        print(f"✓ Success: {execution_time:.4f} seconds with {backend} (hash: {result_hash})")
        return execution_time, result_hash
        
    except Exception as e:
        print(f"✗ Error with {backend}: {e}")
        return None

if __name__ == "__main__":
    # Dataset sizes (number of households)
    household_sizes = [2**15-1, 2**15, 2**16, 2**17, 2**18, 2**19, 2**20, 2**21]
    backends = ["numpy", "jax"]
    
    results = {}
    
    # Add metadata
    results["metadata"] = {
        "timestamp": datetime.now().isoformat(),
        "household_sizes": household_sizes,
        "backends": backends
    }
    
    for backend in backends:
        print(f"\n{'='*60}")
        print(f"Testing {backend} backend")
        print(f"{'='*60}")
        
        for N_households in household_sizes:
            result = run_benchmark(N_households, backend)
            if result:
                time_taken, result_hash = result
                results[f"{N_households}_{backend}_time"] = time_taken
                results[f"{N_households}_{backend}_hash"] = result_hash
            else:
                results[f"{N_households}_{backend}_time"] = None
                results[f"{N_households}_{backend}_hash"] = None
            print()
    
    # Save results to JSON file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"benchmark_results_{timestamp}.json"
    with open(filename, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to: {filename}")
    
    print(f"\n{'='*80}")
    print("SUMMARY TABLE")
    print(f"{'='*80}")
    
    # Print header
    print(f"{'Households':<12}", end="")
    for backend in backends:
        print(f"{backend + '_time':<12}{backend + '_hash':<12}", end="")
    print()
    
    print("-" * (12 + len(backends) * 24))
    
    # Print data rows
    for N_households in household_sizes:
        print(f"{N_households:<12,}", end="")
        for backend in backends:
            time_key = f"{N_households}_{backend}_time"
            hash_key = f"{N_households}_{backend}_hash"
            
            time_val = results.get(time_key)
            hash_val = results.get(hash_key)
            
            if time_val is not None:
                print(f"{time_val:<12.4f}{hash_val:<12}", end="")
            else:
                print(f"{'FAILED':<12}{'N/A':<12}", end="")
        print()
    
    # Print performance comparison
    print(f"\n{'='*60}")
    print("PERFORMANCE COMPARISON")
    print(f"{'='*60}")
    print(f"{'Households':<12}{'NumPy (s)':<12}{'JAX (s)':<12}{'NumPy Hash':<12}{'JAX Hash':<12}{'Speedup':<12}")
    print("-" * 72)
    
    for N_households in household_sizes:
        numpy_time = results.get(f"{N_households}_numpy_time")
        jax_time = results.get(f"{N_households}_jax_time")
        numpy_hash = results.get(f"{N_households}_numpy_hash")
        jax_hash = results.get(f"{N_households}_jax_hash")
        
        if numpy_time is not None and jax_time is not None:
            speedup = numpy_time / jax_time
            speedup_str = f"{speedup:.2f}x" if speedup >= 1 else f"1/{jax_time/numpy_time:.2f}x"
            print(f"{N_households:<12,}{numpy_time:<12.4f}{jax_time:<12.4f}{numpy_hash or 'N/A':<12}{jax_hash or 'N/A':<12}{speedup_str:<12}")
        else:
            print(f"{N_households:<12,}{'FAILED':<12}{'FAILED':<12}{'N/A':<12}{'N/A':<12}{'N/A':<12}")
    
    print("\nNote: Speedup > 1.0 means JAX is faster than NumPy")
    print("Note: Identical hashes across backends confirm numerical consistency")
